package sample.sample;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.remote.SessionId;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class GoogleSearch {
	public static final String AUTOMATE_USERNAME = "ritia";
	public static final String AUTOMATE_ACCESS_KEY = "IhJg3iv6ldrK8PY9tQrbpZCLM8QL1PBRLDrcn1N8t1pmS5HKAa";
	public static final String URL = "https://" + AUTOMATE_USERNAME + ":" + AUTOMATE_ACCESS_KEY
			+ "@hub.lambdatest.com/wd/hub";

	@BeforeTest
	public void setup() {
		com.lambdatest.utils.ExtentReportListner.onTestStart();
	}

	public static void googleSearch(WebDriver driver) throws MalformedURLException, InterruptedException {
		// Open google.com
		driver.get("https://www.google.com/");
		WebElement element = driver.findElement(By.name("q"));
		element.sendKeys("Lambdatest");
		element.submit();
		Thread.sleep(5000);
		Assert.assertEquals("Lambdatest - Google Search", driver.getTitle());
		driver.quit();
	}

	@Test
	public static void launchChrome()
			throws InterruptedException, UnsupportedEncodingException, URISyntaxException, IOException {
		DesiredCapabilities caps = new DesiredCapabilities();
		caps.setCapability("build", "your build name");
		caps.setCapability("name", "your test name");
		caps.setCapability("platform", "Windows 10");
		caps.setCapability("browserName", "Chrome");
		caps.setCapability("version", "100.0");
		caps.setCapability("resolution", "1600x1200");
		caps.setCapability("tunnel", false);
		com.lambdatest.utils.LambdaTestApi ltApi = new com.lambdatest.utils.LambdaTestApi();
		com.lambdatest.utils.ExtentReportListner reporter = new com.lambdatest.utils.ExtentReportListner();
		WebDriver driver = new RemoteWebDriver(new URL(URL), caps);
		SessionId sessionid = ((RemoteWebDriver) driver).getSessionId();
		String session_id = sessionid.toString();

		googleSearch(driver);
		System.out.println(ltApi.getSessionDetails(session_id));
		String sessionName = ltApi.getValue(ltApi.getSessionDetails(session_id), "name");
		ltApi.markTestStatus(session_id, "FAILED", "Fail");
		reporter.onTestFailure(sessionName);

	}

	@Test
	public static void launchEdge()
			throws InterruptedException, UnsupportedEncodingException, URISyntaxException, IOException {
		DesiredCapabilities caps = new DesiredCapabilities();
		caps.setCapability("build", "your build name");
		caps.setCapability("name", "your test name");
		caps.setCapability("platform", "Windows 10");
		caps.setCapability("browserName", "MicrosoftEdge");
		caps.setCapability("version", "100.0");
		caps.setCapability("resolution", "1600x1200");
		caps.setCapability("tunnel", false);
		com.lambdatest.utils.LambdaTestApi ltApi = new com.lambdatest.utils.LambdaTestApi();
		com.lambdatest.utils.ExtentReportListner reporter = new com.lambdatest.utils.ExtentReportListner();
		WebDriver driver = new RemoteWebDriver(new URL(URL), caps);
		SessionId sessionid = ((RemoteWebDriver) driver).getSessionId();
		System.out.println(sessionid);

		googleSearch(driver);

		String session_id = sessionid.toString();
		String sessionName = ltApi.getValue(ltApi.getSessionDetails(session_id), "name");
		System.out.println(ltApi.getSessionDetails(session_id));
		ltApi.markTestStatus(session_id, "FAILED", "Fail");
		reporter.onTestFailure(sessionName);
	}

	@Test
	public static void launchSafari()
			throws InterruptedException, UnsupportedEncodingException, URISyntaxException, IOException {
		DesiredCapabilities caps = new DesiredCapabilities();
		caps.setCapability("build", "your build name");
		caps.setCapability("name", "your test name");
		caps.setCapability("platform", "macOS Mojave");
		caps.setCapability("browserName", "Safari");
		caps.setCapability("version", "12.0");
		caps.setCapability("resolution", "1920x1080");
		caps.setCapability("tunnel", false);
		com.lambdatest.utils.LambdaTestApi ltApi = new com.lambdatest.utils.LambdaTestApi();
		com.lambdatest.utils.ExtentReportListner reporter = new com.lambdatest.utils.ExtentReportListner();
		WebDriver driver = new RemoteWebDriver(new URL(URL), caps);
		SessionId sessionid = ((RemoteWebDriver) driver).getSessionId();
		System.out.println(sessionid);

		googleSearch(driver);
		String session_id = sessionid.toString();
		String sessionName = ltApi.getValue(ltApi.getSessionDetails(session_id), "name");
		System.out.println(ltApi.getSessionDetails(session_id));
		ltApi.markTestStatus(session_id, "PASSED", "Pass");
		
		JSONObject videoResponse = ltApi.getVideo(session_id);
		Map<String, String> metadata = new LinkedHashMap<>();
		metadata.put("View Test", "<a href='https://automation.lambdatest.com/test?sessionId="+session_id+"' target='_blank'>Logs</a>");
		metadata.put("Download Test", "<a href='"+videoResponse.getString("url")+"'>Video</a>");
		metadata.put("Watch Test ", "<video width='400' controls><source src='"+videoResponse.getString("url")+"' type='video/mp4'></video>");
		reporter.onTestPass(sessionName, metadata);
	}

	@Test
	public static void launchFirefox()
			throws InterruptedException, UnsupportedEncodingException, URISyntaxException, IOException {
		DesiredCapabilities caps = new DesiredCapabilities();
		caps.setCapability("build", "your build name");
		caps.setCapability("name", "your test name");
		caps.setCapability("platform", "macOS Mojave");
		caps.setCapability("browserName", "Firefox");
		caps.setCapability("version", "99.0");
		caps.setCapability("resolution", "1920x1080");
		caps.setCapability("tunnel", false);
		com.lambdatest.utils.LambdaTestApi ltAPI = new com.lambdatest.utils.LambdaTestApi();
		com.lambdatest.utils.ExtentReportListner reporter = new com.lambdatest.utils.ExtentReportListner();
		WebDriver driver = new RemoteWebDriver(new URL(URL), caps);
		SessionId sessionid = ((RemoteWebDriver) driver).getSessionId();

		googleSearch(driver);

		String session_id = sessionid.toString();
		String sessionName = ltAPI.getValue(ltAPI.getSessionDetails(session_id), "name");
		System.out.println(ltAPI.getSessionDetails(session_id));
		ltAPI.markTestStatus(session_id, "PASSED", "Pass");
		
		JSONObject videoResponse = ltAPI.getVideo(session_id);
		
		Map<String, String> metadata = new LinkedHashMap<>();
		metadata.put("View Test", "<a href='https://automation.lambdatest.com/test?sessionId="+session_id+"' target='_blank'>Logs</a>");
		metadata.put("Download Test", "<a href='"+videoResponse.getString("url")+"'>Video</a>");
		metadata.put("View Test", "<video width='400' controls><source src='"+videoResponse.getString("url")+"' type='video/mp4'></video>");
		reporter.onTestPass(sessionName, metadata);
	}

	@AfterTest
	public void teardown() {
		com.lambdatest.utils.ExtentReportListner.onFinish();
	}

	public static void mark(SessionId sessionid) throws URISyntaxException, UnsupportedEncodingException, IOException {
		URI uri = new URI(
				"https://ritia:IhJg3iv6ldrK8PY9tQrbpZCLM8QL1PBRLDrcn1N8t1pmS5HKAa@api.lambdatest.com/automation/api/v1/"
						+ sessionid + ".json");
		HttpPut putRequest = new HttpPut(uri);

		ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
		nameValuePairs.add((new BasicNameValuePair("status", "passed")));
		nameValuePairs.add((new BasicNameValuePair("reason", "")));
		putRequest.setEntity(new UrlEncodedFormEntity(nameValuePairs));
		HttpClientBuilder.create().build().execute(putRequest);
	}
}
